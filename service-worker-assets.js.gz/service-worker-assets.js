self.assetsManifest = {
  "version": "IoDyTTfV",
  "assets": [
    {
      "hash": "sha256-ja4uUMiF9DaKC6i70QQKS43L28DEXcADIy7O58owlyg=",
      "url": "Lectur.Site.styles.css"
    },
    {
      "hash": "sha256-6+cqjPBvvNvjju/dR0myA9rVBeZD6uJ/cya5VPBbVp0=",
      "url": "_framework/Aliencube.YouTubeSubtitlesExtractor.lsx4sew4cm.wasm"
    },
    {
      "hash": "sha256-kiD87S/tghFUydyHWNfGo1G3AnugOsqK5Y55LSHS43w=",
      "url": "_framework/AngleSharp.up7648hgwu.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-odUDKmqUoGWxJ4P5K0ik977Bhe8POGtVaL9L5yEs4+Y=",
      "url": "_framework/Lectur.Site.r51yoypqwu.wasm"
    },
    {
      "hash": "sha256-a1eim6U4GsteM+snoRqVKLFGQPr39whnX6+BTsH0nJw=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.z6fq0m7wgh.wasm"
    },
    {
      "hash": "sha256-XPuZIdRQFsu+fnbuBLWsvajexpgKtYmByJAakp7P0bs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.gtg2riohx5.wasm"
    },
    {
      "hash": "sha256-9cH5NSQE3U7VwUM62vH/wpDKCnz6m0Xe806PqQRzGcw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.nl4zcw382h.wasm"
    },
    {
      "hash": "sha256-+JCy0zkk9g2LmiZQjYazB3P7aKDfiN6kSHePnSoueds=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.snbsh5u2kf.wasm"
    },
    {
      "hash": "sha256-gCsWYeSuR1g1zoObfPGuii2CQ5qWY3as/EC3T4fTQ5w=",
      "url": "_framework/Microsoft.AspNetCore.Components.sl3pxbktvi.wasm"
    },
    {
      "hash": "sha256-s/FvG7U5ugFleh6rEuS9vtrsiqw2mLs6NocEPDE7Xvg=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.7ratitftie.wasm"
    },
    {
      "hash": "sha256-a4c/v/ee+g+mJy6NrAVN8UyHatUkGo+36/EvnsKT8+g=",
      "url": "_framework/Microsoft.CSharp.p78c8vyrc5.wasm"
    },
    {
      "hash": "sha256-KEcBleD6VHIpzpcamfOOfxjIWtWP8pIylFvBoCI0LA8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.kluld7hkla.wasm"
    },
    {
      "hash": "sha256-I+ORHI7AYMZSCN0X5zoJJSq7ZIi5b5kceZ05wd0QyTU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.n3ebrrwa2p.wasm"
    },
    {
      "hash": "sha256-2F+FmltouxVRJOaJOQtdvnmMMFikR2RExYDecjxamTA=",
      "url": "_framework/Microsoft.Extensions.Configuration.k9ow1z1wdv.wasm"
    },
    {
      "hash": "sha256-HB7K284jw/VVXeIYdHVibvC/xfZ4WJqc8RazL0ZNCB8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.c48wlizdpq.wasm"
    },
    {
      "hash": "sha256-MOVlPkeO9+8Nu3CBHZqiF9YgpspbjBuCIS4K9LqliPs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.clr2lmubvg.wasm"
    },
    {
      "hash": "sha256-MPKpQueKgg8WNZlDS50Q66EkecX2PNmwNNX2eJ8ACr4=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.8aohh77r19.wasm"
    },
    {
      "hash": "sha256-0PwVT3DJI3W4JqGJbzbuXm7Z6pEsGxwIJp8zWaidzJw=",
      "url": "_framework/Microsoft.Extensions.Logging.g06jewh4ge.wasm"
    },
    {
      "hash": "sha256-j6OzRkwAr6dRtI5CnnoLZ8YvU/+xUW3BkehrQWeZzCA=",
      "url": "_framework/Microsoft.Extensions.Options.7exurhso5d.wasm"
    },
    {
      "hash": "sha256-94QoZadgwzeiFIU+yLaR2X8Nu3IA4MJHyHNo3rfcep8=",
      "url": "_framework/Microsoft.Extensions.Primitives.xuv72fcd9m.wasm"
    },
    {
      "hash": "sha256-nZFChzIl/GGjBbp6aHyOmjD/LOHZZz6ZZtXZtVpIhWs=",
      "url": "_framework/Microsoft.IdentityModel.Abstractions.r67cznsdk3.wasm"
    },
    {
      "hash": "sha256-RvGLFe9+YHoe5Owle2azhfPOiUCRs77E+Vewb5F76Hk=",
      "url": "_framework/Microsoft.IdentityModel.JsonWebTokens.y96uqzji9k.wasm"
    },
    {
      "hash": "sha256-oi4Q+ZX3ixsCw+dfGOzNsp+bjbEih2LqS0i4QC8o94g=",
      "url": "_framework/Microsoft.IdentityModel.Logging.qio6563xoo.wasm"
    },
    {
      "hash": "sha256-eCzbJ6Xqhgr7IKxgY2XhkzPyGxc/4L3y2pbNj3S6EPg=",
      "url": "_framework/Microsoft.IdentityModel.Tokens.ooxg5ow15h.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-zEDzT1B3mQWPEvcLi0C3RF9R7DUkJ0e7y2saXBnQr0c=",
      "url": "_framework/Microsoft.JSInterop.o3nhoy5wco.wasm"
    },
    {
      "hash": "sha256-GlXMWKvDs45M2pACoR3Y4Qh8mcrOZGljqmvJY+6JZ5s=",
      "url": "_framework/Newtonsoft.Json.qkbufwhni2.wasm"
    },
    {
      "hash": "sha256-r1R/ZnH360hrWTNQ4gJ7huzq4SKDgTRxDdx07191Me4=",
      "url": "_framework/System.Collections.Concurrent.nydo8ke5mv.wasm"
    },
    {
      "hash": "sha256-XiT4DJ3pmLTbNcWhnEwkJIg6baswSHJEZu/hxHvyWeA=",
      "url": "_framework/System.Collections.Immutable.20iq6ijyt3.wasm"
    },
    {
      "hash": "sha256-1ZEFn9WVMDWZXJMBDZS6MRRHJu06SCr6lUm6sqqXr7s=",
      "url": "_framework/System.Collections.NonGeneric.rcy5tt6cdu.wasm"
    },
    {
      "hash": "sha256-5sD/3tZuHNn5yEd8jxeqsFHSksx9Ivn8yx3NU0Xuqg8=",
      "url": "_framework/System.Collections.Specialized.unwzbxye6s.wasm"
    },
    {
      "hash": "sha256-NZUjEkh+Cespzk4gJTqqz3nRGY8j8ubRpnfW9eM6bkc=",
      "url": "_framework/System.Collections.xt0o7hnfu7.wasm"
    },
    {
      "hash": "sha256-PGfHb/sHGH0a5DhAdjSGCNDLL84XO9NAFfemlaF2k/I=",
      "url": "_framework/System.ComponentModel.Annotations.0zdulwh4uj.wasm"
    },
    {
      "hash": "sha256-VKvLp9nvrcJRvkQvU+8GM6ZwDNo1V0EkD+A8bkL2BTc=",
      "url": "_framework/System.ComponentModel.Primitives.w545rze7xe.wasm"
    },
    {
      "hash": "sha256-IJuqIFQf6RAmO2Pm8+6H7s5cIeT57r9ewiE5n2vOVsU=",
      "url": "_framework/System.ComponentModel.TypeConverter.k75f734db3.wasm"
    },
    {
      "hash": "sha256-obBakEZvaM9lm9x1ZZMQRDGDN4uSW5R6KhQcq6cu7T0=",
      "url": "_framework/System.ComponentModel.xgcmsz4yg2.wasm"
    },
    {
      "hash": "sha256-Q/Uv2QCMdm82gmZAZGgEkZMwM0rILMPZLhZRRTRtlaA=",
      "url": "_framework/System.Console.34rslqu7ht.wasm"
    },
    {
      "hash": "sha256-Yur/bnABoYRru/j7Bt/WhVtuxwHGDqCNNdspTqcx1WI=",
      "url": "_framework/System.Data.Common.y8m7yzj2cm.wasm"
    },
    {
      "hash": "sha256-Ii/W0nQhojCzdgi/9EuUYxrIxXI9GwgB9XC2nohQsFI=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.qxu5x532hi.wasm"
    },
    {
      "hash": "sha256-Uye4FtGLdZSX5Or2eNQmfHrAO7EjjUFEqypJFtozdzI=",
      "url": "_framework/System.Diagnostics.TraceSource.pt4ll29r10.wasm"
    },
    {
      "hash": "sha256-foTNG0qjsDunkrYigoCgedLeJwZkBffSPB/Bye50ie0=",
      "url": "_framework/System.Drawing.6jd8d2tt0a.wasm"
    },
    {
      "hash": "sha256-Nc4XUdKnWlMikHdb+uNJss7ELhJyx1/jjiU8sI3OcD4=",
      "url": "_framework/System.Drawing.Primitives.htth9pnsd1.wasm"
    },
    {
      "hash": "sha256-0uljQYkN7r22Bww1ENZAVGTupoPwfKICKYE7IbIfkLU=",
      "url": "_framework/System.IO.Pipelines.ij3x2x6ncl.wasm"
    },
    {
      "hash": "sha256-zveXUz1ZuF5ZPfktNafHjhyfGAOe+kAp/jgivWFI59I=",
      "url": "_framework/System.IdentityModel.Tokens.Jwt.ap87gggq7h.wasm"
    },
    {
      "hash": "sha256-4EuelQNvT9avu64X1xTxqU9VJkvi818gSQy6FNhNk7U=",
      "url": "_framework/System.Linq.Expressions.ggx7znpvgt.wasm"
    },
    {
      "hash": "sha256-Rx2zeqVKtSt2o8N+lDuKaYQbs0G4tsjgfEFwP8GCuFo=",
      "url": "_framework/System.Linq.vm9upi11oe.wasm"
    },
    {
      "hash": "sha256-dfhk2VdxWEfi7qYSLoecVyftXNup+WIPjV7ZaAWdFtc=",
      "url": "_framework/System.Memory.3ykqvvkaok.wasm"
    },
    {
      "hash": "sha256-QKRz7JMR+/Sx1pTRt9IgVBykyNHPSeN9UMA1vzCM3Ok=",
      "url": "_framework/System.Net.Http.82n0zhgghk.wasm"
    },
    {
      "hash": "sha256-4k5vdY2Mby2VElvUvhjWoXlsAGOKryPAAlAGlnU8BAA=",
      "url": "_framework/System.Net.Primitives.2vsccy4k18.wasm"
    },
    {
      "hash": "sha256-oyao+IUKc/oQbmjQtFeWyD8P2fM/7DW7QrhOqHoHmVI=",
      "url": "_framework/System.Net.Requests.vhyk79py98.wasm"
    },
    {
      "hash": "sha256-nXzrJsp0FDE9v2p8kL+BQm8DDENZLdmaKX1DI17sMy0=",
      "url": "_framework/System.Net.ServicePoint.91zh148sb2.wasm"
    },
    {
      "hash": "sha256-zfxLAbEPf0yMTItDShAfHdiVDey4xex4dZMIOMa4fHo=",
      "url": "_framework/System.Net.WebHeaderCollection.7nbtnr29kk.wasm"
    },
    {
      "hash": "sha256-AnTIYQ6+zSBZuNYN3qitSmBtMbXGcW2FsUlSAU9uJU4=",
      "url": "_framework/System.ObjectModel.u9i62wtl07.wasm"
    },
    {
      "hash": "sha256-HiVAwf3LLO5RLsJgjDjNjZOCG4Tckr86CO119ewZK4Y=",
      "url": "_framework/System.Private.CoreLib.irs2zx4vcn.wasm"
    },
    {
      "hash": "sha256-DLe7I2piSQtjXH4Cwoc83zg5xxYCrTt969jiP2vRqHM=",
      "url": "_framework/System.Private.Uri.ckn3dkays0.wasm"
    },
    {
      "hash": "sha256-/Uqm2++7e0nVv+3BHPI+//TY9HK/B0MeZFaOftwXxcY=",
      "url": "_framework/System.Private.Xml.Linq.baxud1ax7i.wasm"
    },
    {
      "hash": "sha256-ii3U1C2F42s6BYmHy70OoXlK0WY1gEjManHDZKrTIYs=",
      "url": "_framework/System.Private.Xml.awo6yulykx.wasm"
    },
    {
      "hash": "sha256-5WT6OEMvJvSMbq89UrFK3Kb8nxLFwH72/xyUi0u8klc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.fvnlb9gyjd.wasm"
    },
    {
      "hash": "sha256-cxhuEBJNQUM/OXjcNoGGQ9nsuGXg9zXhOLkFhlZcwKE=",
      "url": "_framework/System.Reflection.Emit.Lightweight.f9yc0ooct1.wasm"
    },
    {
      "hash": "sha256-PhT9saMLTTOnfFUn6jZl5Ue1xofm8VI9ltaRDGacEo0=",
      "url": "_framework/System.Reflection.Primitives.yc3n3m8w3m.wasm"
    },
    {
      "hash": "sha256-md4ze17qLC3ujNEyYMDppG885Zr2OIz0Iwg3NUEbh2c=",
      "url": "_framework/System.Runtime.3ddrh5o96o.wasm"
    },
    {
      "hash": "sha256-3IoLyXDPZlSSNuf0cCFYH/6pnHsiIz+bg/ptKuGnMiI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4wymnd9fjf.wasm"
    },
    {
      "hash": "sha256-N1+pYV5afTFT5v5qt87NoJpwE8VPXNovFnMH1B6CX5o=",
      "url": "_framework/System.Runtime.InteropServices.nkxlqengop.wasm"
    },
    {
      "hash": "sha256-cBqBAYGvSjULD2MqmNp2UkqLahDBcPpqgVFEk8zLg7k=",
      "url": "_framework/System.Runtime.Numerics.kbx3jrt58l.wasm"
    },
    {
      "hash": "sha256-QqdC5qhlQ4NYT4bYlTsADR/ROq/Ul5/+ScSrP6UDIGw=",
      "url": "_framework/System.Runtime.Serialization.Formatters.yk1hpb8hua.wasm"
    },
    {
      "hash": "sha256-ZTbsR/sGTtn/+knCz7GbBDh0iHwMuMwutlz5ZnaJ4EE=",
      "url": "_framework/System.Runtime.Serialization.Primitives.713pmemzjm.wasm"
    },
    {
      "hash": "sha256-MzOy0FfkQ6PlQnrhXMo7BsVrfL0ODy7ri/xfChrUkyA=",
      "url": "_framework/System.Security.Claims.toxdholets.wasm"
    },
    {
      "hash": "sha256-UPd2XqAElmRC9K8w/lQ3LuicpVDrj7s3jTWBS3rlnew=",
      "url": "_framework/System.Security.Cryptography.w4imy4ggg4.wasm"
    },
    {
      "hash": "sha256-/zxkliazoKy1DLf61XD15J2gqBeccea6erCJ4zQYEfg=",
      "url": "_framework/System.Text.Encoding.CodePages.5jx52q2eez.wasm"
    },
    {
      "hash": "sha256-OZ4c9SX2dEKeMLuJtxWcDNhiKVSfDp94ZDkGZDLYWH0=",
      "url": "_framework/System.Text.Encoding.Extensions.fq9ut2x94f.wasm"
    },
    {
      "hash": "sha256-Pwzawg4zJdC5lIyz1AM3dUYbNt/j7hE+Qo+qC3X39yg=",
      "url": "_framework/System.Text.Encodings.Web.l3kos337af.wasm"
    },
    {
      "hash": "sha256-8DdNTge9PcRMDmAmLB0MfE0Y3slPnHVdwCUKMx9tmCc=",
      "url": "_framework/System.Text.Json.gwavfcl2u8.wasm"
    },
    {
      "hash": "sha256-EpIrylLIPstYRTG7Qqwnt/fuXP9qJds3dByNjoodttc=",
      "url": "_framework/System.Text.RegularExpressions.u1plkbklmy.wasm"
    },
    {
      "hash": "sha256-Dlio8i22EH3GTsu2OrgUi1hkD2MThp3g0hHb2mkkv8Q=",
      "url": "_framework/System.Threading.ik9qxdinuq.wasm"
    },
    {
      "hash": "sha256-RtdKVUs8iHhh1iIgweFWvWkCtAc/CEVC7Mq/isxfysc=",
      "url": "_framework/System.Web.HttpUtility.2he4hhexab.wasm"
    },
    {
      "hash": "sha256-JH2xrHoPze3JMRfEdHB+v49DP2GBYXfK1SHBHjP/fL4=",
      "url": "_framework/System.Xml.Linq.464ny307vp.wasm"
    },
    {
      "hash": "sha256-B1adm9xPGRQYklVsNIjD57NkkfiQSk+Ufc87e8vNbYQ=",
      "url": "_framework/System.Xml.ReaderWriter.zdhgungwzg.wasm"
    },
    {
      "hash": "sha256-zjT5irorAs27nSid+JPfzi1sOxysrSxVySkuCH7PGCg=",
      "url": "_framework/System.Xml.XDocument.28lj1ijytg.wasm"
    },
    {
      "hash": "sha256-DM5iEENhrifGKn33Y7cqRzxC0OtHXYOKO13icwIazj8=",
      "url": "_framework/System.cunp5qiwjj.wasm"
    },
    {
      "hash": "sha256-3uZR73aHGg6UGLwKQFVxat8iVUx2wz6+ITWDegM8qRU=",
      "url": "_framework/YoutubeTranscriptApi.ighbss29g4.wasm"
    },
    {
      "hash": "sha256-7ILHGqeRC05d8JzBoVFrp9OnXhHO/sgqIdTTm1Velto=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-VSrDABliXym1uaVGf/4XAZdHT7sA5xiMiD/TmJeALDc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-QgAJsJSEDZ9XA0g3PW3EffgXg+ymMp2uRhGnkVsOxQY=",
      "url": "_framework/dotnet.native.aqhezbunpl.wasm"
    },
    {
      "hash": "sha256-HyBzcYNpT2l19+f1bpjNOa1oFoLe3K4JIQ6GsFK5m6I=",
      "url": "_framework/dotnet.native.rtblh4npr3.js"
    },
    {
      "hash": "sha256-gbZjXNFbH7V8lcix+H0TUDJHLeFUA3n3IMu7fLh4D80=",
      "url": "_framework/dotnet.runtime.d1pzlaz2ez.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-emmli+vHmrVHWX2orGtPSXJomNoFreKR4UnQGyIZuyE=",
      "url": "_framework/netstandard.iu7zbf9xxt.wasm"
    },
    {
      "hash": "sha256-YFzGg6f8Bf0m0D5SWSJlD6tc0Pllkn3dRkfdPbED5Ik=",
      "url": "appSettings.json"
    },
    {
      "hash": "sha256-qRIsIBwZ1CLkKStAQvtV3JgL1LsMVMBFapDklG7XPsA=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YrR60KWG3oGBeh50PzCnU6k2v234InFpmFdAOOd/vXQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-Q7H+R/LhJEYdc7tKE/u0pDX/4uXFllV0lS59Y0x2O5o=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-bh2MPERxpapO8puYMtsGsQnZEv7/fRMSkKRWyofQn+Y=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-P1zMFKuxc8hGAF1ol4FkFJKq0nytSNZ0Fxt27tJ5yLU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-wbnN/Vu4StYrh8yYLoq8XYs4+j3ELQG+/W3c8TXRdV4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-BdWcgt3+cDA103g/rMPhMinFBr0vrsDpwDfw9vdRFHM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-wFTGfK2PR1T31rRzxwCZplpawXOGDKZRLu/p97yoShU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-452+1O9+BQmxzjH+xjGwrOkwrJqtWvGZX6KhGN2vJr8=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-mz57hS1A5Wx7j/T8fCuVMbB4ViRy++SoOhqrOCDzflQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-EkoixIbNqUq5rWlahR/0Y5esnEvK3NJKYlHrnro0VIU=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-EbBNHTlgRA9Qq83Qk0j3HwuUR7e14RcPpMtMYVSl8lE=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
